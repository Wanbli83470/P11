#!/bin/bash
cd /home/thomas/Bureau/P11_ESTIVAL_THOMAS/venv 
. bin/activate
cd /home/thomas/Bureau/P11_ESTIVAL_THOMAS 
python3.7 update.py
